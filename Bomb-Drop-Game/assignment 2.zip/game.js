var upPressed = false;
var downPressed = false;
var leftPressed = false;
var rightPressed = false;
var lastPressed = false;
var score = 0;

function keyup(event) {
	var player = document.getElementById('player');
	if (event.keyCode == 37) {
		leftPressed = false;
		lastPressed = 'left';
	}
	if (event.keyCode == 39) {
		rightPressed = false;
		lastPressed = 'right';
	}
	if (event.keyCode == 38) {
		upPressed = false;
		lastPressed = 'up';
	}
	if (event.keyCode == 40) {
		downPressed = false;
		lastPressed = 'down';
	}

	player.className = 'character stand ' + lastPressed;
}


function move() {
	var player = document.getElementById('player');
	var positionLeft = player.offsetLeft;
	var positionTop = player.offsetTop;
	if (downPressed) {
		var newTop = positionTop + 1;

		var element = document.elementFromPoint(player.offsetLeft, newTop + 32);
		if (element.classList.contains('sky') == false) {
			player.style.top = newTop + 'px';
		}

		if (leftPressed == false) {
			if (rightPressed == false) {
				player.className = 'character walk down';
			}
		}
	}
	if (upPressed) {
		var newTop = positionTop - 1;

		var element = document.elementFromPoint(player.offsetLeft, newTop);
		if (element.classList.contains('sky') == false) {
			player.style.top = newTop + 'px';
		}

		if (leftPressed == false) {
			if (rightPressed == false) {
				player.className = 'character walk up';
			}
		}
	}
	if (leftPressed) {
		var newLeft = positionLeft - 1;

		var element = document.elementFromPoint(newLeft, player.offsetTop);
		if (element.classList.contains('sky') == false) {
			player.style.left = newLeft + 'px';
		}


		player.className = 'character walk left';
	}
	if (rightPressed) {
		var newLeft = positionLeft + 1;

		var element = document.elementFromPoint(newLeft + 32, player.offsetTop);
		if (element.classList.contains('sky') == false) {
			player.style.left = newLeft + 'px';
		}

		player.className = 'character walk right';
	}

}


function keydown(event) {
	if (event.keyCode == 37) {
		leftPressed = true;
	}
	if (event.keyCode == 39) {
		rightPressed = true;
	}
	if (event.keyCode == 38) {
		upPressed = true;
	}
	if (event.keyCode == 40) {
		downPressed = true;
	}
}


function myLoadFunction() {
	time = setInterval(move, 10);
	document.addEventListener('keydown', keydown);
	document.addEventListener('keyup', keyup);
	var butt = document.getElementsByClassName('start')[0];
	butt.addEventListener('click', go);
}
function go() {
	var butt = document.getElementsByClassName('start')[0];
	butt.style.display = 'none';
	play();
}
function play() {
	miss = setInterval(bomb, 550);
	fall = setInterval(drop, 8);
}

/* this is bomb code*/

function bomb() {
	var up = document.getElementsByClassName('sky')[0];
	var bomb = document.createElement('div');
	bomb.className = 'bomb';
	bomb.style.top = up.offsetTop;
	var random = Math.ceil(Math.random() * 37);
	bomb.style.left = random * 46 + 'px';
	up.appendChild(bomb);
}

/* bomb falling */

function drop() {
	var nucle = document.getElementsByClassName('bomb');
	var character = document.getElementById('player');
	var top = parseInt(character.offsetTop);
	var left = parseInt(character.offsetLeft);
	for (var i = 0; nucle.length > i; i++) {
		var blasting = nucle[i];
		var right = parseInt(blasting.offsetTop);
		var LEFT = parseInt(blasting.offsetLeft);
		blasting.style.top = right + 1 + 'px';
		if (left < LEFT) {
			blasting.style.left = LEFT - 1 + 'px';
		}
		blast();
	}
}

/*for explosion*/


function blast() {
	var nucle = document.getElementsByClassName('bomb');
	var character = document.getElementById('player');
	var top = parseInt(character.style.top);
	var left = parseInt(character.style.left);
	for (var i = 0; nucle.length > i; i++) {
		var blasting = nucle[i];
		var right = parseInt(blasting.style.top);
		var LEFT = parseInt(blasting.style.left);
		if (top == right) {
			blasting.className = 'explosion';
			if (LEFT <= left + 16 && LEFT >= left - 16) {
				var lifeline = document.getElementsByTagName('ul')[0];
				var health = document.getElementsByTagName('li');
				lifeline.removeChild(health[0]);
				if (health.length == 0) {
					over();
			
				}
			}
		}
		if (blasting.className == "explosion") {
			setTimeout(function () {
				var up = document.getElementsByClassName('sky')[0];
				var blasting = document.getElementsByClassName('explosion');
				for (var i = 0; i < blasting.length; i++) {
					up.removeChild(blasting[i]);
					total += 1;
				}
			}, 370);
		}

	}

}

function over() {
	console.log("GameOver");
	clearInterval(miss);
	clearInterval(fall);
	clearInterval(time);
	document.removeEventListener('keyup', keyup);
	document.removeEventListener('keydown', keydown);
	setTimeout(show, 200);
	var butt = document.getElementsByClassName('start')[0];
	butt.style.display = 'block';
	butt.innerHTML = " GAME OVER";
	butt.addEventListener("click", front);

}
function show() {
}
function front() {
	location.reload();
}

document.addEventListener('DOMContentLoaded', myLoadFunction);
